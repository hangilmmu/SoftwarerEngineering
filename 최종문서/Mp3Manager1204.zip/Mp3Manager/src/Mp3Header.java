
public class Mp3Header {
	String FName;
	String Name;
	String Artist;
	String Album;
	String Year;
	String Comment;
	String Path;
}
