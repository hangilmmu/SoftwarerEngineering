import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class MainFrame extends JFrame {
	ListFrame LF;
	DBConnecter DBC;
	JRadioButton []radio;
	int nowIndex;
	JLabel lab1;
	JLabel lab2;
	JLabel lab3;
	JLabel artistLab;
	JLabel albumLab;
	JLabel musicLab;
	
	public MainFrame() {
		setTitle("Mp3 manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		DBC = new DBConnecter();
		LF = new ListFrame(DBC);
				
		radio = new JRadioButton[3];
		ButtonGroup btnG = new ButtonGroup();
		radio[0] = new JRadioButton("Music");
		radio[1] = new JRadioButton("Album");
		radio[2] = new JRadioButton("Artist");		
		for(int i=0; i<radio.length; i++){
			btnG.add(radio[i]);
			radio[i].setSize(70, 30);
			radio[i].setLocation(10 + i*70, 90);
			//radio[i].addItemListener(new RadioCheck());
			add(radio[i]);
		}
		radio[2].setSelected(true);
		
		nowIndex = 0;
		
		JButton back = new JButton("����");
		back.addActionListener(new undoPlay());
		back.setLocation(20, 120);
		back.setSize(70, 30);
		add(back);
		
		JButton play = new JButton("���");
		play.setLocation(90, 120);
		play.setSize(70, 30);
		add(play);
		
		JButton next = new JButton("����");
		next.addActionListener(new NextPlay());		
		next.setLocation(160, 120);
		next.setSize(70, 30);
		add(next);
		
		JButton list = new JButton("List");
		listOpen lstOp = new listOpen(this, LF);
		list.addActionListener(lstOp);
		list.setLocation(210, 10);
		list.setSize(70, 30);
		add(list);
		
		lab1 = new JLabel("Artist:");
		lab1.setLocation(10, 10);
		lab1.setSize(50, 30);
		add(lab1);
		
		lab2 = new JLabel("Album:");
		lab2.setLocation(10, 40);
		lab2.setSize(50, 30);
		add(lab2);
		
		lab3 = new JLabel("Music:");
		lab3.setLocation(10, 70);
		lab3.setSize(50, 30);
		add(lab3);
		
		artistLab = new JLabel();
		artistLab.setLocation(60, 10);
		artistLab.setSize(200, 30);
		add(artistLab);
		
		albumLab = new JLabel();
		albumLab.setLocation(60, 40);
		albumLab.setSize(200, 30);
		add(albumLab);
		
		musicLab = new JLabel();
		musicLab.setLocation(60, 70);
		musicLab.setSize(200, 30);
		add(musicLab);
		
		setSize(300,200);
		setVisible(true);
		
	}
	public static void main(String[] args) {
		new MainFrame();
	}
	
	class NextPlay implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			if(nowIndex < (LF.Mp3List.size()-1)){
				nowIndex++;
				artistLab.setText(LF.Mp3List.get(nowIndex).Artist);
				albumLab.setText(LF.Mp3List.get(nowIndex).Album);
				musicLab.setText(LF.Mp3List.get(nowIndex).Name);
			}
		}		
	}
	
	class undoPlay implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			if(nowIndex > 0){
				nowIndex--;
				artistLab.setText(LF.Mp3List.get(nowIndex).Artist);
				albumLab.setText(LF.Mp3List.get(nowIndex).Album);
				musicLab.setText(LF.Mp3List.get(nowIndex).Name);
			}
		}		
	}
}