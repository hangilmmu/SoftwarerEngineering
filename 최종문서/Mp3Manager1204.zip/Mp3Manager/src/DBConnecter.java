import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DBConnecter {
	Connection conn;
	Statement stmt;
	public DBConnecter(){
		conn = null;
		stmt = null;
		
		try{
			conn = DriverManager.getConnection("jdbc:mysql://localhost",
					"root", "pass");
			stmt = conn.createStatement();			
			stmt.executeQuery("use test");
			
			System.out.println("DB ���� �Ϸ�");
		}catch(Exception e){
			System.out.println("JDBC ����̹� �ε� ����");
		}
		
	}
	public void insertMp3List(ArrayList<Mp3Header> findList) throws SQLException{
		ResultSet rs;
		for(int i=0; i<findList.size(); i++){
			rs = stmt.executeQuery("SELECT FName FROM mp3list WHERE FName = '" +findList.get(i).FName +"'");
			if(rs.next()){
				stmt.executeUpdate("DELETE FROM mp3list WHERE FName = '" +findList.get(i).FName +"'");				
			}
			try{			
				stmt.executeUpdate("INSERT INTO MP3LIST VALUES('"
					+findList.get(i).FName.trim() +"', '" +findList.get(i).Name.trim() +"', '" +findList.get(i).Artist.trim() +"', '"
					+findList.get(i).Album.trim() +"', '" +findList.get(i).Year.trim() +"', '" +findList.get(i).Comment.trim() +"', '"
					+findList.get(i).Path.trim() +"')");
				/*
				System.out.println( "INSERT INTO MP3LIST VALUES('"
					+findList.get(i).FName.trim() +"', '" +findList.get(i).Name.trim() +"', '" +findList.get(i).Artist.trim() +"', '"
					+findList.get(i).Album.trim() +"', '" +findList.get(i).Year.trim() +"', '" +findList.get(i).Comment.trim() +"', '"
					+findList.get(i).Path.trim() +"')");*/
			} catch(Exception e) {
				System.out.println("mp3����Ʈ �߰� ����");
				e.printStackTrace();
			}
		}
	}
	
	public void deleteMp3(String FName){
		try {
			stmt.executeUpdate("DELETE FROM mp3list WHERE FName = '" +FName +"'");
		} catch (SQLException e) {
			System.out.println("mp3���� ����");
			e.printStackTrace();
		}
	}
	
	public void updateMp3(String FName, String Artist, String Album){
		if(Artist != null)
			try {
				stmt.executeUpdate("UPDATE mp3list set Artist = '" +Artist +"' WHERE FName = '" +FName +"'");
			} catch (SQLException e) {
				System.out.println("Artist���� ����");
				e.printStackTrace();
			}
		if(Album != null)
			try {
				stmt.executeUpdate("UPDATE mp3list set Album = '" +Album +"' WHERE FName = '" +FName +"'");
			} catch (SQLException e) {
				System.out.println("Artist���� ����");
				e.printStackTrace();
			}
	}
	
	public ArrayList<Mp3Header> RefreshMp3List(int sortMode){
		ArrayList<Mp3Header> mp3list = new ArrayList<Mp3Header>();
		ResultSet rs;
		String[] sort = {"Artist", "Album", "Name"};
		
		try {
			rs = stmt.executeQuery("SELECT * FROM mp3list ORDER BY " +sort[sortMode]);
			while(rs.next()){
				Mp3Header mp3h = new Mp3Header();
				mp3h.FName = rs.getString("FName");
				mp3h.Name = rs.getString("Name");
				mp3h.Artist = rs.getString("Artist");
				mp3h.Album = rs.getString("Album");
				mp3h.Year = rs.getString("Year");
				mp3h.Comment = rs.getString("Comment");
				mp3h.Path = rs.getString("Path");
				mp3list.add(mp3h);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("mp3����Ʈ ������ �б� ����");
			e.printStackTrace();
		}
		
		return mp3list;
	}
	
}
