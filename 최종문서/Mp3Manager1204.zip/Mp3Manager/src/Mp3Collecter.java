import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.io.*;

import javax.swing.JButton;
import javax.swing.JOptionPane;


public class Mp3Collecter implements ActionListener{
	ArrayList<Mp3Header> findList;
	ListFrame lf;
	DBConnecter DBC;
	
	public Mp3Collecter(DBConnecter DBC, ListFrame lf){
		this.DBC = DBC;
		this.lf = lf;
	}

	public void actionPerformed(ActionEvent e) {
		JButton add = (JButton)e.getSource();
		String path = JOptionPane.showInputDialog(null, "���� ���", "��� Ž��", JOptionPane.PLAIN_MESSAGE);
		if(path != null){
			path = path.replace('\\' , '/');
			findList = new ArrayList<Mp3Header>();
			try {
				readMp3(path);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
			if(findList.size() != 0){
				try {
					DBC.insertMp3List(findList);
					lf.Mp3List = DBC.RefreshMp3List(lf.sortMode);
					lf.fillList();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}//����Ʈ ����
		}
	}//��ư ������
	
	private void readMp3(String path) throws Exception{
		File pathDir = new File(path);
		if(pathDir.exists()){
			File []fileList = pathDir.listFiles();
			for(int i=0; i<fileList.length; i++){
				if(fileList[i].getName().endsWith(".mp3")){
					@SuppressWarnings("resource")
					FileInputStream fis = new FileInputStream(fileList[i]);
					OutputStream bis = new ByteArrayOutputStream();
					
					int ch = 0;
					byte [] b = new byte[128];
					
					fis.skip(fileList[i].length() - 128);
					while((ch = fis.read(b, 0, b.length)) != -1) {
						bis.write(b, 0, ch);
					}
					
					Mp3Header mp3h = new Mp3Header();
					mp3h.FName = fileList[i].getName();
					mp3h.Name = parseParam(b, 3, 30);
					mp3h.Artist = parseParam(b, 33, 30);
					mp3h.Album = parseParam(b, 63, 30);
					mp3h.Year = parseParam(b, 93, 4);
					mp3h.Comment  = parseParam(b, 97, 30);
					mp3h.Path = path;
					findList.add(mp3h);
				}
			}
		} else {
			JOptionPane.showMessageDialog(null, "Not Find Path", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}//���丮 Ž��
	
	public String parseParam(byte [] src, int start, int offset) {
		String paramValue = "";
		int end = start + offset;
		for( int i = start ; i < end ; i++ ) {
			paramValue += (char)src[i];
		}
		return paramValue;
	}//Mp3 ���� ��� �Ľ�
}
