import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class ListFrame extends JFrame {
	Container c;
	DBConnecter DBC;
	ArrayList<Mp3Header> Mp3List;
	JList list;
	JScrollPane listPane;
	JRadioButton []radio;
	int sortMode;
	JLabel lab1;
	JLabel lab2;
	JLabel artistLab;
	JLabel albumLab;
	JButton delet;
	JButton retuch;
	
	public ListFrame(DBConnecter DBC) {
		this.DBC = DBC;
		setTitle("Mp3 List");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(300, 600);
		c = getContentPane();
		c.setLayout(null);
		lab1 = new JLabel("Artist:");
		lab1.setLocation(10, 90);
		lab1.setSize(50, 30);
		c.add(lab1);
		
		lab2 = new JLabel("Album:");
		lab2.setLocation(10, 130);
		lab2.setSize(50, 30);
		c.add(lab2);
		
		artistLab = new JLabel();
		artistLab.setLocation(60, 90);
		artistLab.setSize(200, 30);
		c.add(artistLab);
		
		albumLab = new JLabel();
		albumLab.setLocation(60, 130);
		albumLab.setSize(200, 30);
		c.add(albumLab);
		
		Mp3List = DBC.RefreshMp3List(2);
		
		list = new JList();
		listPane = new JScrollPane(list);
		listPane.setSize(260, 380);
		listPane.setLocation(10, 170);
		list.addListSelectionListener(new ListCheck());
		c.add(listPane);
		
		radio = new JRadioButton[3];
		ButtonGroup btnG = new ButtonGroup();
		radio[0] = new JRadioButton("Artist");
		radio[1] = new JRadioButton("Album");
		radio[2] = new JRadioButton("Music");
		for(int i=0; i<radio.length; i++){
			btnG.add(radio[i]);
			radio[i].setSize(70, 30);
			radio[i].setLocation(10 + i*70, 50);
			radio[i].addItemListener(new RadioCheck());
			c.add(radio[i]);
		}
		radio[2].setSelected(true);		
		
		JButton add = new JButton("ADD");
		add.addActionListener(new Mp3Collecter(DBC, this));
		add.setLocation(10, 10);
		add.setSize(70, 30);
		c.add(add);	
		
		JButton delet = new JButton("DELET");
		delet.addActionListener(new DeleteItem());
		delet.setLocation(90, 10);
		delet.setSize(70, 30);
		c.add(delet);	
		
		JButton retuch = new JButton("RETUCH");
		retuch.addActionListener(new RetuchItem( ));
		retuch.setLocation(170, 10);
		retuch.setSize(80, 30);
		c.add(retuch);	
		
		this.setVisible(false);
	}
	
	public void show(MainFrame MF){
		this.setLocation(MF.getX() + MF.getWidth(), MF.getY());
		this.setVisible(true);
	}
	
	public void fillList(){
		ArrayList<String> fill = new ArrayList<String>();
					
		for(int i=0; i<Mp3List.size(); i++){
			fill.add(Mp3List.get(i).Name);
		}
		list.setListData(fill.toArray());
	}
	
	class RadioCheck implements ItemListener {
		public void itemStateChanged(ItemEvent e){
			if(e.getStateChange() == ItemEvent.DESELECTED)
				return;
			if(radio[0].isSelected()){
				sortMode = 0;
			} else if(radio[1].isSelected()) {
				sortMode = 1;
			} else {
				sortMode = 2;				
			}
			Mp3List = DBC.RefreshMp3List(sortMode);
			fillList();
		}
	}
	
	class ListCheck implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent arg0) {
			int index = list.getSelectedIndex();
			
			if(index != -1){
				artistLab.setText(Mp3List.get(index).Artist);
				albumLab.setText(Mp3List.get(index).Album);
			} else {
				artistLab.setText(null);
				albumLab.setText(null);
			}
		}
	}
	
	class DeleteItem implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			int index = list.getSelectedIndex();
			
			if(index != -1){
				int del = JOptionPane.showConfirmDialog(
					null, "Do you want to delete\n\"" +Mp3List.get(index).Name +"\"?", "DELETE",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
				if(del == 0){
					DBC.deleteMp3(Mp3List.get(index).FName);
					Mp3List = DBC.RefreshMp3List(sortMode);
					fillList();
				}
			}
		}		
	}
	
	class RetuchItem implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			int index = list.getSelectedIndex();
			
			if(index != -1){
				String Artist = JOptionPane.showInputDialog(null, "Change Artist", "RETUCH", JOptionPane.PLAIN_MESSAGE);
				String Album = JOptionPane.showInputDialog(null, "Change Album", "RETUCH", JOptionPane.PLAIN_MESSAGE);
				if(Artist != null || Album != null){
					DBC.updateMp3(Mp3List.get(index).FName, Artist, Album);
					Mp3List = DBC.RefreshMp3List(sortMode);
					fillList();
				}
			}
		}
	}
}
